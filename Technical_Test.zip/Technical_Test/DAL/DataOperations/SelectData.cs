﻿using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataOperations
{
    public class SelectData
    {
        public static List<MeterPoint> SelectAllMeterPoints(List<MeterPoint> MeterPoints)
        {
            return MeterPoints;
        }
        //public MeterPoint SelectMeterPointByMpan(int Mpan)
        //{
        //}
       
    }
}
